<?php
require_once "conexao.php"

$id = $_POST("id");
 

 $prepare_sql = $conn->prepare("DELETE FROM PRODUTOS WHERE id=?");
 if($prepare_sql){
    $prepare_sql->bind_param("i", $id);
    if($prepare_sql->execute()){
        
    }
 }