<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="icon" href="assets/img/logp.jpg" type="image/x-icon">
  <title>Login</title>
</head>
<style>
    .form-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .botao-cadastrar {
      margin-top: 20px;
    }
   
  .container-admin-banner2 {
    text-align: center;
    margin-top: 8px; /* Defina a margem superior corretamente */
    color:white;
  }
</style>
<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center justify-content-center">
    <div class="container" data-aos="fade-up">

      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
        <div class="col-xl-6 col-lg-8">

       <section class="container-admin-banner">
<body>
  <main>
    <section class="container-admin-banner">
      <img src="img/logo-ifsp-removebg.png" class="logo-admin" alt="logo-serenatto">
      <h1>Login IFSP</h1>
      <img class="ornaments" src="img/ornaments-coffee.png" alt="ornaments">
    </section>
    <div class="container-form">
      <form action="processar-login.php" method="POST">

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" placeholder="Digite o seu e-mail" required>

        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" placeholder="Digite a sua senha" required>

        <input type="submit" class="botao-cadastrar" value="Entrar" />
      </form>
    </div>
    <div class="form-container">
      <form action="cadastrar-usuario.php" method="POST">
        <input type="submit" class="botao-cadastrar" value="Usuário novo" />
      </form>
    </div>

  </main>
</body>

</html>